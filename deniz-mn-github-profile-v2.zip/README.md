<img align="right" src="./assets/penguin-walking.gif" width="99" height="99" alt="A cartoon penguin walking with a red scarf and backpack" />

# deniz-mn

Computer Engineering · Semester 7

Learning, one step at a time.

<br clear="all" />

---

### About

I'm a Computer Engineering undergraduate. My projects span artificial intelligence, data science, compiler design, and web application development. I'm particularly interested in artificial intelligence and software engineering, while remaining curious about other areas of computing.
